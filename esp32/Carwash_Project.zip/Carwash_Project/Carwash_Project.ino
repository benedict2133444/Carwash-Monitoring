#include "display.h"
#include "lvgl_port.h"
#include "touch.h"
#include "carwash_logic.h"
#include "espnow.h"
#include "supabase_client.h"
#include "secrets.h"

#include <WiFi.h>
#include <esp_now.h>
#include <esp_wifi.h>

const char* WIFI_SSID = CARWASH_WIFI_SSID;
const char* WIFI_PASSWORD = CARWASH_WIFI_PASSWORD;


void setup()
{
    Serial.begin(115200);
    delay(1000);

    // ==================================================
    // WIFI
    // ==================================================

    WiFi.mode(WIFI_STA);

    Serial.println();
    Serial.println("==============================");
    Serial.println("WIFI SETUP");
    Serial.println("==============================");

    Serial.print("Connecting to Wi-Fi");

    WiFi.begin(
        WIFI_SSID,
        WIFI_PASSWORD
    );

    unsigned long wifiStart = millis();

    while(
        WiFi.status() != WL_CONNECTED &&
        millis() - wifiStart < 15000
    )
    {
        delay(250);
        Serial.print(".");
    }

    Serial.println();

    if(WiFi.status() == WL_CONNECTED)
    {
        Serial.println("Wi-Fi connected!");

        Serial.print("IP address: ");
        Serial.println(WiFi.localIP());

        Serial.print("Wi-Fi channel: ");
        Serial.println(WiFi.channel());

        // Disable Wi-Fi power saving.
        // This improves responsiveness for ESP-NOW.
        esp_wifi_set_ps(WIFI_PS_NONE);

        Serial.println(
            "Wi-Fi power saving disabled"
        );

        // ESP-NOW will automatically use this Wi-Fi channel.
        Serial.print("ESP-NOW will use Wi-Fi channel: ");
        Serial.println(WiFi.channel());
    }
    else
{
    Serial.println(
        "Wi-Fi connection FAILED"
    );

    Serial.println(
        "Continuing in LOCAL MODE"
    );

    // Stop Wi-Fi completely.
    // This allows ESP-NOW to control the radio channel.
    WiFi.disconnect(true, true);

    delay(100);

    WiFi.mode(WIFI_STA);

    delay(100);

    Serial.println(
        "Wi-Fi stopped for LOCAL MODE"
    );
}


    // ==================================================
    // ESP-NOW
    // ==================================================

    Serial.println();
    Serial.println("==============================");
    Serial.println("ESP-NOW SETUP");
    Serial.println("==============================");

    espnow_init();

    Serial.println(
        "ESP-NOW initialized"
    );

    Serial.println("1");


    // ==================================================
    // DISPLAY
    // ==================================================

    display_init();

    Serial.println("2");

    lvgl_port_init();

    Serial.println("3");


    // ==================================================
    // CARWASH LOGIC
    // ==================================================

    carwash_logic_init();


    // ==================================================
    // SUPABASE
    // ==================================================

    supabase_init();

    Serial.println("4");

    Serial.println();
    Serial.println("==============================");
    Serial.println("SYSTEM READY");
    Serial.println("==============================");
}


void loop()
{
    // ==================================================
    // LOCAL REAL-TIME SYSTEM
    // ==================================================

    lv_tick_inc(2);

    lvgl_port_task();

    carwash_logic_task();

    espnow_task();


    // ==================================================
    // SUPABASE
    //
    // This function does NOT perform HTTP.
    // Actual Supabase work runs in its background task.
    // ==================================================

    supabase_task();

    delay(2);
}
