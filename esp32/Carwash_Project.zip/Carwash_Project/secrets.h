#ifndef SECRETS_H
#define SECRETS_H

// Wi-Fi
#define CARWASH_WIFI_SSID "YOTC-DC799F"
#define CARWASH_WIFI_PASSWORD "70360927"

// Supabase
#define CARWASH_SUPABASE_URL "https://uakazzooibnwlamdqsiw.supabase.co"
#define CARWASH_SUPABASE_KEY "sb_publishable_UtiypfyK-6ahnwGF8qfcAA_64udsQd8"

#endif