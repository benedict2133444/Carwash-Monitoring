#include "supabase_client.h"
#include "secrets.h"

#include <WiFi.h>
#include <WiFiClientSecure.h>
#include <HTTPClient.h>
#include <esp_wifi.h>

#include "carwash_logic.h"
#include "espnow.h"

#include "freertos/FreeRTOS.h"
#include "freertos/task.h"


// ======================================================
// SUPABASE
// ======================================================

const char* SUPABASE_URL = CARWASH_SUPABASE_URL;
const char* SUPABASE_KEY = CARWASH_SUPABASE_KEY;


// ======================================================
// UPDATE CONTROL
// ======================================================

volatile bool supabaseUpdateRequested = false;

unsigned long lastSupabaseUpdate = 0;

const unsigned long SUPABASE_UPDATE_INTERVAL = 60000;


// ======================================================
// FAILURE CONTROL
// ======================================================

unsigned long lastSupabaseFailure = 0;

const unsigned long SUPABASE_FAILURE_COOLDOWN = 120000;


// ======================================================
// HTTPS TIMEOUTS
// ======================================================

const uint16_t SUPABASE_CONNECT_TIMEOUT = 2000;

const uint16_t SUPABASE_HTTP_TIMEOUT = 3000;


// ======================================================
// BACKGROUND TASK
// ======================================================

TaskHandle_t supabaseTaskHandle = nullptr;


// ======================================================
// REQUEST UPDATE
// ======================================================

void requestSupabaseUpdate()
{
    supabaseUpdateRequested = true;

    Serial.println(
        "SUPABASE UPDATE REQUESTED"
    );
}


// ======================================================
// SEND MACHINE STATUS
// ======================================================

bool sendMachineStatus()
{
    Serial.println();
    Serial.println("==============================");
    Serial.println("SUPABASE SEND START");
    Serial.println("==============================");


    // --------------------------------------------------
    // WIFI CHECK
    // --------------------------------------------------

    if(WiFi.status() != WL_CONNECTED)
    {
        Serial.println(
            "Supabase: Wi-Fi NOT connected"
        );

        Serial.println(
            "Skipping HTTP request"
        );

        Serial.println(
            "SUPABASE SEND END"
        );

        return false;
    }


    Serial.println(
        "Supabase: Wi-Fi connected"
    );


    // --------------------------------------------------
    // CREATE JSON
    // --------------------------------------------------

    String json = "{";

    json += "\"id\":1,";

    json += "\"water_status\":\"";
    json += getWaterStatus();
    json += "\",";

    json += "\"soap_status\":\"";
    json += getSoapStatus();
    json += "\",";

    json += "\"blower_status\":\"";
    json += getBlowerStatus();
    json += "\",";

    json += "\"faucet_status\":\"";
    json += getFaucetStatus();
    json += "\",";

    json += "\"water_remaining\":";
    json += String(getWaterRemainingSeconds());
    json += ",";

    json += "\"soap_remaining\":";
    json += String(getSoapRemainingSeconds());
    json += ",";

    json += "\"blower_remaining\":";
    json += String(getBlowerRemainingSeconds());
    json += ",";

    json += "\"faucet_remaining\":";
    json += String(getFaucetRemainingSeconds());
    json += ",";

    json += "\"is_online\":";
    json += (
        isControllerOnline()
        ? "true"
        : "false"
    );

    json += "}";


    Serial.println("JSON:");
    Serial.println(json);


    // --------------------------------------------------
    // HTTPS
    // --------------------------------------------------

    WiFiClientSecure client;

    client.setInsecure();

    HTTPClient http;


    String endpoint =
        String(SUPABASE_URL) +
        "/rest/v1/machine_status";


    // --------------------------------------------------
    // TIMEOUTS
    // --------------------------------------------------

    http.setConnectTimeout(
        SUPABASE_CONNECT_TIMEOUT
    );

    http.setTimeout(
        SUPABASE_HTTP_TIMEOUT
    );


    Serial.println(
        "Starting HTTP connection..."
    );


    if(!http.begin(client, endpoint))
    {
        Serial.println(
            "Supabase: HTTP BEGIN FAILED"
        );

        Serial.println(
            "SUPABASE SEND END"
        );

        return false;
    }


    // --------------------------------------------------
    // HEADERS
    // --------------------------------------------------

    http.addHeader(
        "apikey",
        SUPABASE_KEY
    );

    http.addHeader(
        "Authorization",
        String("Bearer ") + SUPABASE_KEY
    );

    http.addHeader(
        "Content-Type",
        "application/json"
    );

    http.addHeader(
        "Prefer",
        "resolution=merge-duplicates"
    );


    // --------------------------------------------------
    // POST
    // --------------------------------------------------

    Serial.println(
        "Sending POST to Supabase..."
    );


    unsigned long startTime = millis();

    int httpCode = http.POST(json);

    unsigned long duration =
        millis() - startTime;


    Serial.print(
        "Supabase HTTP status: "
    );

    Serial.println(httpCode);

    Serial.print(
        "Supabase request duration: "
    );

    Serial.print(duration);

    Serial.println(" ms");


    // --------------------------------------------------
    // SUCCESS
    // --------------------------------------------------

    if(
        httpCode >= 200 &&
        httpCode < 300
    )
    {
        Serial.println(
            "SUPABASE UPDATE SUCCESS"
        );

        http.end();

        client.stop();

        Serial.println(
            "SUPABASE SEND END"
        );

        return true;
    }


    // --------------------------------------------------
    // FAILURE
    // --------------------------------------------------

    Serial.println(
        "SUPABASE UPDATE FAILED"
    );


    if(httpCode > 0)
    {
        String response =
            http.getString();

        Serial.println(
            "Supabase response:"
        );

        Serial.println(response);
    }
    else
    {
        Serial.println(
            "No HTTP response received."
        );
    }


    // --------------------------------------------------
    // CLEANUP
    // --------------------------------------------------

    http.end();

    client.stop();


    Serial.println(
        "SUPABASE SEND END"
    );

    return false;
}


// ======================================================
// BACKGROUND TASK
// ======================================================

void supabase_background_task(
    void *parameter
)
{
    Serial.println(
        "SUPABASE BACKGROUND TASK STARTED"
    );


    for(;;)
    {
        unsigned long now = millis();


        // ==================================================
        // INTERNET OFF
        // ==================================================

        if(WiFi.status() != WL_CONNECTED)
        {
            // No HTTP.
            // No retry.
            // Local ESP-NOW continues independently.

            supabaseUpdateRequested = false;

            vTaskDelay(
                pdMS_TO_TICKS(2000)
            );

            continue;
        }


        // ==================================================
        // PERIODIC UPDATE
        // ==================================================

        if(
            now - lastSupabaseUpdate >=
            SUPABASE_UPDATE_INTERVAL
        )
        {
            supabaseUpdateRequested = true;
        }


        // ==================================================
        // NO REQUEST
        // ==================================================

        if(!supabaseUpdateRequested)
        {
            vTaskDelay(
                pdMS_TO_TICKS(1000)
            );

            continue;
        }


        // ==================================================
        // NORMAL UPDATE INTERVAL
        // ==================================================

        if(
            now - lastSupabaseUpdate <
            SUPABASE_UPDATE_INTERVAL
        )
        {
            vTaskDelay(
                pdMS_TO_TICKS(1000)
            );

            continue;
        }


        // ==================================================
        // FAILURE COOLDOWN
        // ==================================================

        if(
            lastSupabaseFailure != 0 &&
            now - lastSupabaseFailure <
            SUPABASE_FAILURE_COOLDOWN
        )
        {
            vTaskDelay(
                pdMS_TO_TICKS(2000)
            );

            continue;
        }


        // ==================================================
        // CONSUME REQUEST
        // ==================================================

        supabaseUpdateRequested = false;

        lastSupabaseUpdate = now;


        // ==================================================
        // PERFORM HTTP
        // ==================================================

        bool success =
            sendMachineStatus();


        // ==================================================
        // FAILURE BACKOFF
        // ==================================================

        if(!success)
        {
            lastSupabaseFailure =
                millis();

            Serial.println(
                "SUPABASE FAILURE COOLDOWN"
            );

            Serial.println(
                "Retry delayed for 120 seconds"
            );
        }


        // ==================================================
        // GIVE CPU BACK
        // ==================================================

        vTaskDelay(
            pdMS_TO_TICKS(1000)
        );
    }
}


// ======================================================
// INITIALIZATION
// ======================================================

void supabase_init()
{
    Serial.println();
    Serial.println("==============================");
    Serial.println("SUPABASE CLIENT");
    Serial.println("==============================");


    supabaseUpdateRequested = false;

    lastSupabaseUpdate =
        millis();

    lastSupabaseFailure = 0;


    // ==================================================
    // CREATE BACKGROUND TASK
    // ==================================================

    BaseType_t result =
        xTaskCreatePinnedToCore(
            supabase_background_task,
            "SupabaseTask",
            8192,
            nullptr,
            0,
            &supabaseTaskHandle,
            0
        );


    if(result == pdPASS)
    {
        Serial.println(
            "Supabase background task created"
        );
    }
    else
    {
        Serial.println(
            "ERROR: Supabase background task failed"
        );
    }
}


// ======================================================
// MAIN LOOP SUPABASE TASK
// ======================================================

void supabase_task()
{
    // IMPORTANT:
    //
    // Absolutely no HTTP here.
    //
    // The local LVGL + ESP-NOW loop remains fast.

    return;
}